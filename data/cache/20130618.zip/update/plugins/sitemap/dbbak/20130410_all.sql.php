<?php exit;?>DROP TABLE IF EXISTS dc_plugin_sitemap
CREATE TABLE `dc_plugin_sitemap` (  `name` varchar(250) default NULL,  `config` int(1) unsigned default NULL) ENGINE=MyISAM DEFAULT CHARSET=utf8;
INSERT INTO dc_plugin_sitemap VALUES('status','0')
