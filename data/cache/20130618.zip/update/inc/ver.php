<?php
$config['ver'] = '2.0.0'; //版本号
$config['ver_name'] = 'QUGUOCMS 稳定版'; //版本名称
$config['ver_date'] = '20151214'; //版本时间
?>